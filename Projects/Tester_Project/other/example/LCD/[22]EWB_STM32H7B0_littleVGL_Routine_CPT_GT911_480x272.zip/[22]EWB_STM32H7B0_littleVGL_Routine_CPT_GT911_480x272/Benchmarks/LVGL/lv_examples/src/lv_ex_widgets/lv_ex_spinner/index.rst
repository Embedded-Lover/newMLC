C
^

Simple spinner 
""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_spinner/lv_ex_spinner_1
  :language: c

MicroPython
^^^^^^^^^^^
